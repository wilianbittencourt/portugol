/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class contaBancaria {
    private String nomeProprietario;
    private int numeroAgencia;
    private int numeroConta;

    public String getNomeProprietario() {
        return nomeProprietario;
    }

    public void setNomeProprietario(String nomeProprietario) {
        this.nomeProprietario = nomeProprietario;
    }

    public int getNumeroAgencia() {
        return numeroAgencia;
    }

    public void setNumeroAgencia(int numeroAgencia) {
        this.numeroAgencia = numeroAgencia;
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    private float saldo;
    
    public void depositar(int valor){
        saldo = saldo + valor;
    }
    
    public boolean sacar(int valor){
        if(valor <= saldo){
        saldo = saldo - valor;
        return true;
        }else{
            return false;
        }
    }
    
    public float consultar(){
        return saldo;
    }

    
    
    
}
