/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Principal {
    public static void main(String[] args){
        
        contaBancaria c = new contaBancaria();
        
        c.setNomeProprietario("Felisbina");
        c.setNumeroAgencia(666);
        c.setNumeroConta(66);
        c.setSaldo(10000);
        
        System.out.println("saldo: "+ c.consultar());
        System.out.println("Numero Agencia: "+ c.getNumeroAgencia());
        System.out.println("Numero Conta: "+ c.getNumeroConta());
        System.out.println("Nome: "+ c.getNomeProprietario());
        boolean saque = c.sacar(1000);
        if (saque == false){
            System.out.println("Faltou dinheiro, sociedade capitalista!!");
        }else{
            System.out.println("Sobrou dinheiro, ufa!!");
        }
        
        c.depositar(11);
        System.out.println("saldo: "+ c.consultar());
        c.sacar(20);
        System.out.println("saldo: "+ c.consultar());
        
    }
    
}
