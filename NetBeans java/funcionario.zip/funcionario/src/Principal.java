/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Principal {
    public static void main(String[] args){
    funcionario f = new funcionario();
    
    f.setNome("zé");
    f.setDepartamento("marketing");
    f.setRg("6660666066");
    f.setSalario(2500);
    f.setDataAdmissao("10/08/2023");
    
    System.out.println("Nome: "+ f.getNome());
    System.out.println("Departamento: "+ f.getDepartamento());
    System.out.println("salario: "+ f.getSalario());
    System.out.println("RG: "+ f.getRg());
    System.out.println("Data de admissao: "+ f.getDataAdmissao());
    f.recebeAumento(80);
    System.out.println("Salario atualizado: R$ "+ f.getSalario());
    f.calculaGanhoAnul();
    }
    
}
