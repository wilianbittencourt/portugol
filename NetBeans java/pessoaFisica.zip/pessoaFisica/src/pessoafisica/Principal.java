/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pessoafisica;

/**
 *
 * @author Aluno
 */
public class Principal {
    public static void main(String[] args){
        
        pessoaFisica p = new pessoaFisica();
        
        p.setNome("Tabajara Silveira");
        p.setCpf("666.666.666-66");
        p.setRg("1234567890");
        p.setIdade(66);
        p.setEndereço("Rua Não sei, do bairro seila");
        p.setTelefone("(54) 91234-5678");
        
        System.out.println("Nome: "+ p.getNome());
        System.out.println("CPF: "+ p.getCpf());
        System.out.println("RG: "+ p.getRg());
        System.out.println("idade: "+ p.getIdade());
        System.out.println("endereço: "+ p.getEndereço());
        System.out.println("telefone: "+ p.getTelefone());
        
    }
}
