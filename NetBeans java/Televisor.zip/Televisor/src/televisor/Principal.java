/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package televisor;

import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class Principal {
    public static void main(String[] args){
        Scanner teclado = new Scanner (System.in);
       Televisor t = new Televisor();
        
       System.out.println("Digite um valor para o volume");
       t.alteraVolume(teclado.nextInt());
       t.diminuiVolume();
       t.diminuiVolume();
       System.out.println("volume: "+t.retornaVolume());
       
    }
}
